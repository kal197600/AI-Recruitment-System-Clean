from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.candidates import router as candidate_router
from app.api.jobs import router as job_router
from app.api.applications import router as application_router
from app.api.import_email import router as import_router
from app.api.screening import router as screening_router

from app.database.database import Base, engine

# Import all models so SQLAlchemy registers them
from app.models.candidate import Candidate
from app.models.job import Job
from app.models.application import Application
from app.models.candidate_file import CandidateFile
from app.models.imported_email import ImportedEmail
from app.models.screening_result import ScreeningResult
from app.api.candidate_files import router as candidate_file_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI Recruitment System",
    version="1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(candidate_router)
app.include_router(job_router)
app.include_router(application_router)
app.include_router(import_router)
app.include_router(screening_router)
app.include_router(candidate_file_router)

@app.get("/")
def home():
    return {
        "status": "running",
        "message": "AI Recruitment System API",
    }