from app.ai.ai_service import AIService
from app.parsers.pdf_parser import PDFParser


class CVParser:

    def __init__(self):

        self.pdf_parser = PDFParser()

        self.ai_service = AIService()

    # --------------------------------------------------

    def parse(self, pdf_path):

        resume_text = self.pdf_parser.extract_text(
            pdf_path
        )

        if not resume_text.strip():

            raise Exception(
                "No text extracted from PDF."
            )

        candidate = self.ai_service.parse_resume(
            resume_text
        )

        return candidate